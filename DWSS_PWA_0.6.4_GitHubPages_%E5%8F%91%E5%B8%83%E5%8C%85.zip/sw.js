/* DWSS PWA Service Worker - offline-first; GitHub Pages project-site safe */
const APP_VERSION = '0.6.4';
const CACHE_NAME = `dwss-kolwezi-${APP_VERSION}`;
const PRECACHE_URLS = [
  './', './index.html', './boot.js', './app.js', './pwa.js', './sw.js',
  './dictionary.js.gz', './french-fallback.js', './manifest.webmanifest', './icon-192.png',
  './icon-512.png', './apple-touch-icon.png', './favicon-32.png',
  './cover.jpg', './COPYRIGHT_AND_LICENSE.txt'
];
self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await cache.addAll(PRECACHE_URLS);
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.filter((name) => name.startsWith('dwss-kolwezi-') && name !== CACHE_NAME).map((name) => caches.delete(name)));
    await self.clients.claim();
  })());
});
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'DWSS_SKIP_WAITING') self.skipWaiting();
});
self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      try {
        const fresh = await fetch(request);
        if (fresh && fresh.ok) {
          const cache = await caches.open(CACHE_NAME);
          await cache.put(new URL('./index.html', self.registration.scope).href, fresh.clone());
        }
        return fresh;
      } catch (_) {
        return (await caches.match(new URL('./index.html', self.registration.scope).href)) || Response.error();
      }
    })());
    return;
  }
  event.respondWith((async () => {
    const cached = await caches.match(request);
    if (cached) return cached;
    try {
      const fresh = await fetch(request);
      if (fresh && fresh.ok) {
        const cache = await caches.open(CACHE_NAME);
        cache.put(request, fresh.clone()).catch(() => {});
      }
      return fresh;
    } catch (_) { return Response.error(); }
  })());
});
