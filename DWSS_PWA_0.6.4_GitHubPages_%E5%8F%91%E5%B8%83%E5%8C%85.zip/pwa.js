(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const state = $('pwaState'), message = $('pwaMessage'), networkBadge = $('networkBadge');
  const installButton = $('installAppBtn'), updateButton = $('checkUpdateBtn');
  let deferredInstallPrompt = null, registration = null, reloading = false, updateServiceReady = false;
  const isStandalone = () => window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  const setState = (text, kind, detail) => { state.textContent=text; state.className='chip '+(kind||''); if(detail) message.textContent=detail; };
  const updateNetwork = () => {
    const online=navigator.onLine;
    networkBadge.textContent=online?'● 网络已连接':'● 当前离线';
    networkBadge.style.borderColor=online?'#ffffff70':'#ffdf9a';
    networkBadge.style.color=online?'#e6fff3':'#ffdf9a';
    if(!online && navigator.serviceWorker && navigator.serviceWorker.controller)
      setState('离线运行中','pwa-state-ok','当前没有网络连接。已缓存的词库查询、短句匹配和个人词库维护仍可在本机使用；联网后才能检查更新。');
  };
  window.addEventListener('online',updateNetwork); window.addEventListener('offline',updateNetwork);
  if(isStandalone()) setState('已从桌面启动','pwa-state-ok','DWSS 已以独立窗口方式运行。联网时可检查更新；首次安装后请确认离线资源已缓存。');
  else setState('浏览器打开','pwa-state-warn','首次打开请保持网络连接，等待页面、完整词库、封面和图标缓存完成。缓存成功后，后续可断网使用。');
  updateButton.disabled=true; updateButton.title='正在初始化更新检查服务';
  window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstallPrompt=e;installButton.hidden=false;installButton.textContent='安装到手机桌面';});
  installButton.addEventListener('click',async()=>{if(!deferredInstallPrompt)return;deferredInstallPrompt.prompt();await deferredInstallPrompt.userChoice.catch(()=>null);deferredInstallPrompt=null;installButton.hidden=true;});
  window.addEventListener('appinstalled',()=>{installButton.hidden=true;setState('安装完成','pwa-state-ok','DWSS 已添加到手机桌面。请打开一次并确认离线资源已缓存；以后可断网使用。');});
  if(!window.isSecureContext && location.hostname!=='localhost' && location.hostname!=='127.0.0.1') setState('需要 HTTPS','pwa-state-bad','当前网址不是安全 HTTPS 连接，浏览器不能启用离线缓存和版本检查。请使用 DWSS 官方 HTTPS 网址。');
  if('serviceWorker' in navigator && (window.isSecureContext || location.hostname==='localhost' || location.hostname==='127.0.0.1')) {
    window.addEventListener('load',async()=>{
      try {
        registration=await navigator.serviceWorker.register('./sw.js',{scope:'./'}); await navigator.serviceWorker.ready;
        updateServiceReady=true; updateButton.disabled=false; updateButton.title='检查 DWSS 是否有新版本';
        if(navigator.storage?.persist) navigator.storage.persist().then(granted=>{if(granted)console.info('[DWSS] 浏览器已授予持久化存储。');}).catch(()=>{});
        if(registration.waiting && navigator.serviceWorker.controller) showUpdateAvailable();
        registration.addEventListener('updatefound',()=>{const worker=registration.installing;if(!worker)return;worker.addEventListener('statechange',()=>{
          if(worker.state==='installed' && navigator.serviceWorker.controller) showUpdateAvailable();
          else if(worker.state==='activated') setState('离线资源已缓存','pwa-state-ok','核心程序、词库、封面和图标已由 Service Worker 缓存。现在可以断开网络测试。');
        });});
        if(navigator.serviceWorker.controller) setState('离线资源已缓存','pwa-state-ok','核心程序、当地词库、法语辅助词表、新封面和图标已缓存。现在可以断开网络测试。');
        else setState('离线缓存初始化完成','pwa-state-warn','更新检查服务已连接。正在完成首次离线缓存；请保持网络并稍后重新打开一次软件，再测试断网使用。');
        updateNetwork();
      } catch(error) { console.error('[DWSS] Service Worker registration failed:',error);updateButton.disabled=true;setState('更新服务连接失败','pwa-state-bad','浏览器未能注册离线更新服务。请确认使用官方 HTTPS 地址、网络正常，并尝试刷新页面；若使用微信等内置浏览器，请改用 Chrome 或 Safari。'); }
    });
  } else if('serviceWorker' in navigator) { updateButton.disabled=true;setState('等待安全网址','pwa-state-warn','请通过 HTTPS 官方网址打开本软件，浏览器才能启用 PWA 离线缓存和版本更新检查。'); }
  else { updateButton.disabled=true;setState('浏览器不支持更新检查','pwa-state-bad','当前浏览器不支持 Service Worker。请使用最新版 Android Chrome 或 iPhone Safari 打开 DWSS 官方 HTTPS 网址。'); }
  function showUpdateAvailable(){updateButton.textContent='安装软件更新';updateButton.classList.add('primary');updateButton.classList.remove('soft');updateButton.dataset.updateReady='1';updateButton.disabled=false;setState('发现新版本','pwa-state-warn','有新的 DWSS 软件版本已下载。点击“安装软件更新”后将刷新页面。更新不会主动删除本机自定义词库，但仍建议先备份。');}
  updateButton.addEventListener('click',async()=>{
    if(updateButton.dataset.updateReady==='1' && registration?.waiting){registration.waiting.postMessage({type:'DWSS_SKIP_WAITING'});return;}
    if(!updateServiceReady || !registration){setState('更新服务正在初始化','pwa-state-warn','页面刚打开时，浏览器需要先注册离线更新服务。请等待几秒后再点“检查更新”；如果按钮仍不可用，请刷新官方 HTTPS 页面或换用 Chrome / Safari。');return;}
    if(!navigator.onLine){setState('当前离线','pwa-state-warn','没有网络，无法检查服务器更新；已缓存的软件仍可继续使用。');return;}
    updateButton.disabled=true;setState('正在检查更新','pwa-state-warn','正在联系 DWSS 官方网站检查是否有新版本，请稍候。');
    try{await registration.update();if(!registration.waiting && !registration.installing)setState('当前已是最新版本','pwa-state-ok','更新服务已连接，服务器没有提供更新版本。当前软件可以继续正常使用。');}
    catch(error){console.warn('[DWSS] update check failed:',error);setState('暂时无法检查更新','pwa-state-warn','虽然设备显示已联网，但更新服务器暂时没有响应。请稍后重试；当前已缓存版本仍可使用。');}
    finally{updateButton.disabled=false;}
  });
  navigator.serviceWorker?.addEventListener('controllerchange',()=>{if(reloading)return;reloading=true;window.location.reload();}); updateNetwork();
})();
