(() => {
'use strict';
const DB = Array.isArray(window.SW_DB) ? window.SW_DB : [];
const FRENCH_RAW = window.SW_FRENCH || {};
const FRENCH_READINGS = window.SW_FRENCH_READINGS || {};
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const norm = s => String(s || '').normalize('NFKC').replace(/[\s　]+/g,'').replace(/[，。！？；：、,.!?;:（）()“”"']/g,'').toLowerCase();
const CUSTOM_KEY = 'sw_custom_dictionary_v1';
const PRODUCT_META = Object.freeze({id:'com.dwss.kolwezi.swahili',name:'DWSS 科卢韦齐斯瓦西里语助手',owner:'DWSS / 陈谍',version:'0.6.3'});
const FRENCH_MAP = new Map(Object.entries(FRENCH_RAW).map(([k,v]) => [norm(k),v]));
const FRENCH_KEYS = [...FRENCH_MAP.keys()].sort((a,b) => b.length-a.length);
// Conservative Chinese near-meaning aliases. Only substitute when the preferred local term exists in the source dictionary.
// These are wording alternatives, not claims that the Chinese terms are perfectly identical in every context.
const LOCAL_SYNONYM_ALIASES = Object.freeze({
 '检查':['查看','检看/看看'],
 '检查一下':['查看','检看/看看'],
 '检查一遍':['查看','检看/看看'],
 '查看一下':['查看','检看/看看'],
 '巡视':['巡逻','查看'],
 '巡查':['巡逻','查看'],
 '查验':['查看','检看/看看'],
 '核查':['查看','检看/看看'],
 '检验':['查看','检看/看看'],
 '察看':['查看','检看/看看'],
 '检视':['查看','检看/看看'],
 '视察':['查看','检看/看看'],
 '观察':['看','查看'],
 '瞧一瞧':['看','查看'],
 '看一看':['看','查看'],
 '搜寻':['找'],
 '寻找':['找']
});
const ALIAS_KEYS = Object.keys(LOCAL_SYNONYM_ALIASES).sort((a,b)=>b.length-a.length);
const CATEGORIES = ['安保与工作','矿山与设备','日常生活','时间与方位','人称与关系','医疗与健康','市场与饮食','其他'];

function categoryOf(zh){
 const s=zh;
 if(/警卫|警察|门岗|安保|保安|警告|保护|服从|罚款|签字|巡逻|检查|许可|请求|人员|身份证|护照|抓|偷|盗|不允许|不同意|同意|安全|纪律/.test(s))return '安保与工作';
 if(/矿|铜|钴|硫酸|厂房|发电机|发动机|挖掘机|吊车|柴油|汽油|机油|液压|电缆|电线|电机|水泥|混凝土|沙子|石子|搅拌机|设备|装车|工程|油桶|氧气|变压器|电焊|工具|库房|仓库|营地|办公室|主厂房/.test(s))return '矿山与设备';
 if(/昨天|今天|明天|后天|上午|中午|下午|晚上|早上|时间|分钟|小时|星期|前面|后面|左|右|上边|下边|这里|那里|现在/.test(s))return '时间与方位';
 if(/我|你|他|她|我们|你们|他们|先生|女士|男人|女人|小孩|老婆|丈夫|朋友|老人|刚果人|外国人/.test(s))return '人称与关系';
 if(/医院|医生|护士|药|疼|病|疟疾|肚子|头|眼|耳|嘴|手|脚|咳嗽|血/.test(s))return '医疗与健康';
 if(/买|卖|钱|市场|商店|公斤|蔬菜|西红柿|肉|米|饭|水|盐|油|糖|面粉|牛肉|羊肉|猪肉|鱼|喝|吃|饿/.test(s))return '市场与饮食';
 if(/你好|谢谢|请|再见|家|房子|门|窗|床|桌子|衣服|鞋|洗澡|睡觉|起床|厕所|走|过来|回来|去|来|说话|听|看|知道|明白|喜欢|帮助|累|休息/.test(s))return '日常生活';
 return '其他';
}
function loadCustom(){
 try { const x=JSON.parse(localStorage.getItem(CUSTOM_KEY)||'[]'); return Array.isArray(x)?x.filter(v=>v&&typeof v.zh==='string'):[]; }
 catch(e){ return []; }
}
let custom = loadCustom();
let all = [], map = new Map(), keys = [];
function saveCustom(){ localStorage.setItem(CUSTOM_KEY,JSON.stringify(custom)); }
function rebuild(){
 const grouped = new Map();
 for(const item of DB){
  if(!item||!item.zh)continue;
  const k=norm(item.zh); if(!k)continue;
  if(!grouped.has(k))grouped.set(k,{zh:item.zh,variants:(item.variants||[]).map(v=>({...v})),category:categoryOf(item.zh),customIds:[]});
  else grouped.get(k).variants.push(...(item.variants||[]).map(v=>({...v})));
 }
 for(const c of custom){
  const k=norm(c.zh); if(!k)continue;
  if(!grouped.has(k))grouped.set(k,{zh:c.zh,variants:[],category:c.category||categoryOf(c.zh),customIds:[]});
  const item=grouped.get(k); item.category=c.category||item.category||categoryOf(c.zh); item.customIds.push(c.id);
  item.variants.push({reading:c.reading||'',latin:c.latin||'',french:c.french||'',frenchReadingZh:c.frenchReadingZh||'',source:c.source||'用户手动添加',kind:'用户补充',note:c.note||'',customId:c.id});
 }
 all=[...grouped.values()]; map=new Map(all.map(x=>[norm(x.zh),x])); keys=[...all].sort((a,b)=>norm(b.zh).length-norm(a.zh).length);
}
rebuild();
function uniqueLocalVariants(item){
 const seen=new Set();
 return (item.variants||[]).filter(v=>{
  if(!v.reading&&!v.latin)return false;
  const k=norm(v.reading)+'|'+norm(v.latin||''); if(seen.has(k))return false; seen.add(k); return true;
 });
}
function frenchFor(item){
 const v=(item.variants||[]).find(x=>x.french);
 return v?.french || FRENCH_MAP.get(norm(item.zh)) || '';
}
function frenchReadingFor(fr,override=''){
 const manual=String(override||'').trim();
 if(manual)return manual;
 const exact=FRENCH_READINGS[fr];
 if(exact)return exact;
 return approximateFrenchToChinese(fr);
}
// Readable Chinese approximation for French. Frequent phrases and words have curated forms in french-fallback.js;
// this conservative grapheme approximation is a helper only, not IPA and not a native-speaker verification.
function approximateFrenchToChinese(text){
 const known={
  'Veuillez patienter.':'维耶 巴提昂特','Veuillez patienter, je vais aller le chercher.':'维耶 巴提昂特，热 维 阿莱 勒 谢赫谢',
  'Entrez, s\'il vous plaît.':'昂特赫，西勒 武 普莱','Asseyez-vous, s\'il vous plaît.':'阿塞耶 武，西勒 武 普莱',
  'Merci.':'梅西','Merci beaucoup.':'梅西 波库','Bonjour.':'邦茹尔','Bon après-midi.':'邦 阿普赫 米迪','Bonsoir.':'邦苏瓦尔','Au revoir.':'欧赫 沃阿赫',
  'Pas de problème.':'帕 德 普罗布莱姆','Excusez-moi.':'埃克斯居泽 姆瓦','Comment allez-vous ?':'科芒 塔莱 武','Je vais bien.':'热 维 比安',
  'Je ne sais pas.':'热 讷 塞 帕','Je comprends.':'热 孔普朗','Je ne comprends pas.':'热 讷 孔普朗 帕','Où allez-vous ?':'乌 阿莱 武',
  'Où êtes-vous ?':'乌 埃特 武','Faites attention.':'费特 阿唐西翁','Dépêchez-vous.':'德佩谢 武','Ralentissez.':'哈朗蒂塞'
 };
 if(known[text])return known[text];
 const word={
  bonjour:'邦茹尔',merci:'梅西',beaucoup:'波库',veuillez:'维耶',patienter:'巴提昂特',entrez:'昂特赫',suis:'绥',désolé:'德佐莱',excusez:'埃克斯居泽',comment:'科芒',allez:'阿莱',vais:'维',bien:'比安',comprends:'孔普朗',sais:'塞',pas:'帕',attendez:'阿唐代',bureau:'比赫哦',demain:'德曼',matin:'马坦',poste:'波斯特',garde:'嘎赫德',agent:'阿让',sécurité:'塞居里泰',contrôle:'孔特霍勒',véhicule:'维厄居勒',camion:'卡米翁',permis:'佩赫米',conduire:'孔迪赫',carte:'卡赫特',identité:'当蒂泰',dortoir:'多赫图瓦赫',entrepôt:'昂特赫波',magasin:'马嘎赞',générateur:'热内哈特厄赫',moteur:'莫特厄赫',cuivre:'奎弗赫',cobalt:'科巴勒特',usine:'于辛',mine:'米讷',minier:'米涅',ciment:'西芒',béton:'贝通',gravier:'格赫拉维耶',eau:'欧',huile:'于伊勒',gasoil:'嘎佐瓦勒',essence:'埃桑斯',oxygène:'奥克西热讷',casque:'卡斯克',gants:'冈',lampe:'朗普',téléphone:'泰莱丰',visiteur:'维齐特厄赫',chauffeur:'肖弗赫',policier:'波利西耶',ouvrier:'乌弗赫耶',employé:'昂普洛耶',personnel:'佩赫索内勒',collègue:'科勒格',responsable:'赫斯旁萨布勒',superviseur:'叙佩赫维泽赫',patrouille:'帕特赫乌耶',rapport:'哈波赫',amende:'阿芒德',signature:'西尼亚图赫',autorisation:'奥托赫里扎西翁',interdit:'安特赫迪',danger:'当热',urgence:'于赫让斯',incendie:'昂桑迪',ambulance:'昂比兰斯',hôpital:'奥皮塔勒',passeport:'帕斯波赫',liste:'利斯特',nuit:'努伊',jour:'茹赫',repos:'赫波',salaire:'萨莱赫',route:'赫乌特',ville:'维勒',village:'维拉日',marché:'马赫谢',argent:'阿赫让',prix:'普赫伊',tomate:'托马特',oignon:'瓦尼翁',poulet:'普乌莱',poisson:'布瓦松',sel:'塞勒',sucre:'叙克赫',maison:'梅松',chambre:'香布赫',chaise:'谢兹',toilettes:'图瓦莱特',clé:'克莱',serrure:'塞赫于赫',seau:'苏',chaussures:'肖叙赫',outil:'乌蒂',équipement:'埃基普芒',réparation:'赫帕哈西翁',panne:'班恩',batterie:'巴特赫伊',caméra:'卡梅赫啊',surveillance:'叙赫维扬斯',alarme:'阿拉赫姆',extincteur:'埃克斯坦克特厄赫',masque:'马斯克',gilet:'日莱',réunion:'赫于尼翁',équipe:'埃基普',chef:'谢夫',congé:'孔热',blessé:'布莱塞',secours:'瑟库赫',fuite:'弗伊特',pneu:'普讷',frein:'弗赫兰',klaxon:'克拉克松',réservoir:'赫泽赫沃阿赫',température:'唐佩哈图赫',compteur:'孔特厄赫',entretien:'昂特赫蒂安',conforme:'孔福赫姆'
 };
 return String(text||'').split(/(\s+|[.,!?;:，。！？；：])/).map(t=>{
  if(!t||/^\s+$/.test(t)||/^[.,!?;:，。！？；：]$/.test(t))return t;
  const k=t.toLowerCase(); if(word[k])return word[k];
  let x=k;
  const reps=[['eaux','欧'],['eau','欧'],['au','欧'],['ou','乌'],['oi','瓦'],['ch','施'],['gn','尼'],['ph','夫'],['qu','克'],['ill','耶'],['tion','西翁'],['sion','西翁'],['ain','英'],['ein','英'],['an','昂'],['am','昂'],['en','昂'],['em','昂'],['on','翁'],['om','翁'],['un','恩'],['um','恩'],['ai','诶'],['ei','诶'],['é','诶'],['è','诶'],['ê','诶'],['er','诶'],['ez','诶']];
  for(const [a,b] of reps)x=x.split(a).join(b);
  x=x.replace(/h/g,'');
  if(x.length>2&&/[stxdpe]$/.test(x))x=x.slice(0,-1);
  x=x.replace(/c(?=[eiy])/g,'斯').replace(/g(?=[eiy])/g,'日');
  const chars={a:'啊',b:'布',c:'克',d:'德',e:'呃',f:'夫',g:'格',i:'伊',j:'日',k:'克',l:'勒',m:'姆',n:'恩',o:'欧',p:'普',q:'克',r:'赫',s:'斯',t:'特',u:'于',v:'维',w:'瓦',x:'克斯',y:'伊',z:'兹'};
  return [...x].map(c=>chars[c]||c).join('');
 }).join('');
}
function makeId(){return 'u_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,8);}
function validateEntry(data){
 const zh=String(data.zh||'').trim(),reading=String(data.reading||'').trim(),latin=String(data.latin||'').trim(),french=String(data.french||'').trim(),frenchReadingZh=String(data.frenchReadingZh||'').trim();
 if(!zh)return '请填写中文意思。';
 if(!reading&&!latin&&!french)return '请填写当地斯语中文谐音、当地拼写或法语备用表达中的至少一项。';
 if(zh.length>100||reading.length>200||latin.length>200||french.length>200||frenchReadingZh.length>200)return '词条内容过长，请适当缩短。';
 return {zh,reading,latin,french,frenchReadingZh,category:CATEGORIES.includes(data.category)?data.category:categoryOf(zh),source:String(data.source||'用户手动添加').trim().slice(0,100),note:String(data.note||'').trim().slice(0,500)};
}
function addCustomEntry(data){
 const v=validateEntry(data); if(typeof v==='string')return {ok:false,error:v};
 const duplicate=custom.find(c=>norm(c.zh)===norm(v.zh)&&norm(c.reading)===norm(v.reading)&&norm(c.latin)===norm(v.latin)&&norm(c.french)===norm(v.french));
 if(duplicate)return {ok:false,error:'这条自定义词条已经存在。你可以在下方列表中编辑它。'};
 custom.push({...v,id:makeId(),createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()}); saveCustom(); rebuild(); return {ok:true};
}
function updateCustomEntry(id,data){
 const i=custom.findIndex(c=>c.id===id);if(i<0)return {ok:false,error:'没有找到要修改的自定义词条。'};
 const v=validateEntry(data);if(typeof v==='string')return {ok:false,error:v};
 const dup=custom.find((c,j)=>j!==i&&norm(c.zh)===norm(v.zh)&&norm(c.reading)===norm(v.reading)&&norm(c.latin)===norm(v.latin)&&norm(c.french)===norm(v.french));
 if(dup)return {ok:false,error:'相同的自定义词条已存在。'};
 custom[i]={...custom[i],...v,updatedAt:new Date().toISOString()};saveCustom();rebuild();return {ok:true};
}
function deleteCustomEntry(id){const n=custom.length;custom=custom.filter(c=>c.id!==id);if(custom.length===n)return false;saveCustom();rebuild();return true;}
function exportCustom(){return JSON.stringify({app:PRODUCT_META.name,productId:PRODUCT_META.id,owner:PRODUCT_META.owner,appVersion:PRODUCT_META.version,formatVersion:2,exportedAt:new Date().toISOString(),entries:custom},null,2);}
function importCustom(raw){
 let data;try{data=typeof raw==='string'?JSON.parse(raw):raw;}catch(e){return {ok:false,error:'备份内容不是有效的 JSON。'};}
 const entries=Array.isArray(data)?data:data&&Array.isArray(data.entries)?data.entries:null;if(!entries)return {ok:false,error:'没有找到 entries 词条数组。'};
 let added=0,updated=0,skipped=0,legacy=0;
 for(const e of entries){
  // Old English-only backup fields are not silently reinterpreted as French.
  const sourceEntry={...e}; if(!sourceEntry.french&&sourceEntry.english){legacy++;}
  const v=validateEntry(sourceEntry);if(typeof v==='string'){skipped++;continue;}
  const id=String(e.id||'');const byId=id?custom.findIndex(c=>c.id===id):-1;
  const byValue=custom.findIndex(c=>norm(c.zh)===norm(v.zh)&&norm(c.reading)===norm(v.reading)&&norm(c.latin)===norm(v.latin)&&norm(c.french)===norm(v.french));
  if(byId>=0){custom[byId]={...custom[byId],...v,updatedAt:new Date().toISOString()};updated++;}
  else if(byValue>=0){skipped++;}
  else {custom.push({...v,id:id||makeId(),createdAt:e.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString()});added++;}
 }
 saveCustom();rebuild();return {ok:true,added,updated,skipped,legacy};
}
function localReadingVariant(item){return (item.variants||[]).find(v=>v.reading)||null;}
function localLatinVariants(item){return (item.variants||[]).map(v=>v.latin).filter(Boolean);}
function localFrenchOverride(item){const v=(item.variants||[]).find(x=>x.french);return v?.french||'';}
function localFrenchPronOverride(item){const v=(item.variants||[]).find(x=>x.frenchReadingZh);return v?.frenchReadingZh||'';}
function lookupFrenchAt(input,index){
 for(const key of FRENCH_KEYS){const raw=input.slice(index,index+key.length);if(norm(raw)===key)return {key,french:FRENCH_MAP.get(key)};}
 return null;
}
function lookupLocalSynonymAt(input,index){
 for(const alias of ALIAS_KEYS){
  const raw=input.slice(index,index+alias.length);
  if(norm(raw)!==norm(alias))continue;
  for(const target of LOCAL_SYNONYM_ALIASES[alias]){
   const item=map.get(norm(target));
   if(item && (localReadingVariant(item)||localLatinVariants(item).length||frenchFor(item)))return {alias,target,item};
  }
 }
 return null;
}
function tokenize(raw){
 const input=String(raw||'');let i=0;const segments=[];let localChars=0,frenchChars=0,unknownChars=0,localHits=0,frenchHits=0;
 const isPunct=ch=>/[\s，。！？；：、,.!?;:\-—（）()“”"'‘’]/.test(ch);
 while(i<input.length){
  const ch=input[i];
  if(isPunct(ch)){segments.push({type:'punct',text:ch});i++;continue;}
  let found=null,foundLen=0;
  for(const item of keys){const k=item.zh;if(!k)continue;const slice=input.slice(i,i+k.length);if(norm(slice)===norm(k)&&k.length>foundLen){found=item;foundLen=k.length;}}
  // Prefer a curated whole phrase over a shorter local token at the same position.
  // A local exact phrase of equal/greater length still wins, preserving local vocabulary priority.
  // Prefer a longer curated near-meaning phrase over a shorter token, but never over an exact local phrase.
  const alias=lookupLocalSynonymAt(input,i);
  if(alias && alias.alias.length>foundLen){
   const localV=localReadingVariant(alias.item),latin=localLatinVariants(alias.item),fr=localFrenchOverride(alias.item)||frenchFor(alias.item);
   if(localV){segments.push({type:'local',zh:input.slice(i,i+alias.alias.length),canonical:alias.target,reading:localV.reading,latin,source:localV.source||'原始资料',item:alias.item,matchedBy:'近义替代',originalTerm:alias.alias});localChars+=alias.alias.length;localHits++;}
   else if(fr){segments.push({type:'french',zh:input.slice(i,i+alias.alias.length),canonical:alias.target,french:fr,frenchReadingZh:frenchReadingFor(fr,localFrenchPronOverride(alias.item)),source:'近义替代词条的法语备用',matchedBy:'近义替代',originalTerm:alias.alias,latin});frenchChars+=alias.alias.length;frenchHits++;}
   else if(latin.length){segments.push({type:'latinOnly',zh:input.slice(i,i+alias.alias.length),canonical:alias.target,latin,source:'近义替代',matchedBy:'近义替代'});unknownChars+=alias.alias.length;}
   i+=alias.alias.length;continue;
  }
  const phraseFr=lookupFrenchAt(input,i);
  if(phraseFr && !found && phraseFr.key.length>foundLen){
   const pron=frenchReadingFor(phraseFr.french);
   segments.push({type:'french',zh:input.slice(i,i+phraseFr.key.length),canonical:phraseFr.key,french:phraseFr.french,frenchReadingZh:pron,source:'DWSS 法语辅助短语'});
   frenchChars+=phraseFr.key.length;frenchHits++;i+=phraseFr.key.length;continue;
  }
  if(found){
   const localV=localReadingVariant(found),latin=localLatinVariants(found),customFr=localFrenchOverride(found),fr=customFr||frenchFor(found);
   if(localV){segments.push({type:'local',zh:input.slice(i,i+foundLen),canonical:found.zh,reading:localV.reading,latin,source:localV.source||'原始资料',item:found,french:fr});localChars+=foundLen;localHits++;}
   else if(fr){segments.push({type:'french',zh:input.slice(i,i+foundLen),canonical:found.zh,french:fr,frenchReadingZh:frenchReadingFor(fr,localFrenchPronOverride(found)),source:customFr?'用户自定义法语备用':'DWSS 法语辅助词表',latin});frenchChars+=foundLen;frenchHits++;}
   else if(latin.length){segments.push({type:'latinOnly',zh:input.slice(i,i+foundLen),canonical:found.zh,latin,source:'已核验拉丁拼写'});unknownChars+=foundLen;}
   else {segments.push({type:'unknown',text:input.slice(i,i+foundLen)});unknownChars+=foundLen;}
   i+=foundLen;continue;
  }
  const fr=lookupFrenchAt(input,i);
  if(fr){const pron=frenchReadingFor(fr.french);segments.push({type:'french',zh:input.slice(i,i+fr.key.length),canonical:fr.key,french:fr.french,frenchReadingZh:pron,source:'DWSS 法语辅助词表'});frenchChars+=fr.key.length;frenchHits++;i+=fr.key.length;continue;}
  let j=i+1;
  while(j<input.length&&!isPunct(input[j])){
   let exists=false;
   for(const it of keys){if(it.zh.length>0&&norm(input.slice(j,j+it.zh.length))===norm(it.zh)){exists=true;break;}}
   if(!exists&&lookupFrenchAt(input,j))exists=true;
   if(exists)break;j++;
  }
  segments.push({type:'unknown',text:input.slice(i,j)});unknownChars+=(j-i);i=j;
 }
 return {segments,localChars,frenchChars,unknownChars,localHits,frenchHits};
}
function joinParts(parts){return parts.join(' ').replace(/\s+([，。！？；：、,.!?;:])/g,'$1').replace(/([（(])\s+/g,'$1').replace(/\s+([）)])/g,'$1');}
function renderTranslation(){
 const raw=$('inputText').value.trim();
 if(!raw){
  $('resultState').textContent='等待输入';$('resultOriginal').textContent='尚未输入';$('resultReading').textContent='翻译后显示';$('resultReading').classList.add('empty');$('resultLatin').textContent='自定义词条中填写了拉丁拼写时，这里显示相应内容。';$('resultFrench').textContent='本句没有使用法语补位。';$('resultFrenchReading').textContent='如有法语补位，这里同步显示中文近似读法。';$('segmentList').innerHTML='<div class="nores">输入中文后，显示当地斯语命中、法语补位和仍未收录的部分。</div>';return;
 }
 $('resultOriginal').textContent=raw;
 const r=tokenize(raw);
 const mixed=joinParts(r.segments.map(s=>s.type==='local'?s.reading:(s.type==='french'?`${s.frenchReadingZh}（法语）`:(s.type==='latinOnly'?`【当地拼写已收录，中文谐音待补】`:(s.type==='punct'?s.text:`【未收录：${s.text}】`)))));
 const latin=joinParts(r.segments.map(s=>s.type==='local'?(s.latin.length?s.latin.join(' / '):'【本词拉丁拼写未核验】'):(s.type==='french'?`【法语：${s.french}】`:(s.type==='latinOnly'?s.latin.join(' / '):(s.type==='punct'?s.text:`【未收录：${s.text}】`)))));
 const frOnly=joinParts(r.segments.filter(s=>s.type==='french').map(s=>s.french));
 const frReading=joinParts(r.segments.filter(s=>s.type==='french').map(s=>s.frenchReadingZh||frenchReadingFor(s.french)));
 $('resultReading').textContent=mixed||'未找到可拼配词条';$('resultReading').classList.toggle('empty',!mixed);
 $('resultFrench').textContent=frOnly||'本句没有使用法语补位。';
 $('resultFrenchReading').textContent=frReading||'本句没有法语补位，因此无需显示法语中文近似读音。';
 $('resultLatin').textContent=latin||'没有可显示的拼写';
 const total=r.localChars+r.frenchChars+r.unknownChars;const pct=total?Math.round(100*r.localChars/total):0;
 $('resultState').textContent=r.frenchHits?(r.localHits?'当地斯语 + 法语补位':'使用法语补位'):(r.unknownChars?'有未收录部分':'当地词库已匹配');
 $('coverageChip').textContent=`当地斯语覆盖：${pct}%（按字符估算）`;
 $('matchedChip').textContent=`当地词条 ${r.localHits} 段 · 法语补位 ${r.frenchHits} 段 · 未收录 ${r.unknownChars} 字`;
 $('segmentList').innerHTML=r.segments.map(s=>{
  if(s.type==='punct')return `<div class="small-muted">标点 ${esc(s.text)}</div>`;
  if(s.type==='local'){
   const alts=uniqueLocalVariants(s.item).filter(v=>norm(v.reading)!==norm(s.reading));
   const altHtml=alts.length?`<div class="src">资料另有读法：${alts.map(v=>esc(v.reading)+'（'+esc(v.source)+'）').join('；')}。请核对当地说法。</div>`:'';
   return `<div class="seg"><div class="zh">${esc(s.zh)}</div><div class="rd">${esc(s.reading)}${s.latin.length?`<div class="src">当地斯瓦西里语拼写：${esc(s.latin.join(' / '))}</div>`:''}<div class="src">当地词库命中 · ${esc(s.source)}${s.matchedBy==='近义替代'?` · 近义替代：输入“${esc(s.originalTerm)}”，采用词库中的“${esc(s.canonical)}”`:''}</div>${altHtml}</div></div>`;
  }
  if(s.type==='french')return `<div class="seg french-fallback"><div class="zh">${esc(s.zh)}</div><div class="rd">${esc(s.frenchReadingZh||frenchReadingFor(s.french))}（法语）<div class="src">法语备用表达；中文近似读音仅作辅助提示，不是当地斯语读音。</div>${s.matchedBy==='近义替代'?`<div class="src">近义替代：输入“${esc(s.originalTerm)}”，采用“${esc(s.canonical)}”对应的法语备用表达。</div>`:''}<div class="src">法语原文：${esc(s.french)}</div>${s.latin?.length?`<div class="src">原资料/自定义中另有当地拼写：${esc(s.latin.join(' / '))}</div>`:''}</div></div>`;
  if(s.type==='latinOnly')return `<div class="seg unknown"><div class="zh">${esc(s.zh)}</div><div class="rd">找到当地斯语拼写，但没有中文谐音：${esc(s.latin.join(' / '))}<div class="src">请让当地同事补充中文近似发音。</div></div></div>`;
  return `<div class="seg unknown"><div class="zh">${esc(s.text)}</div><div class="rd">当地斯语和法语备用词库均未收录<div class="src">请在“词库维护”中补充当地斯语中文谐音，或补充法语备用表达。</div></div></div>`;
 }).join('')||'<div class="nores">没有匹配结果</div>';
 saveRecent(raw);
}
function saveRecent(raw){let h=JSON.parse(localStorage.getItem('sw_history')||'[]');h=[raw,...h.filter(x=>x!==raw)].slice(0,30);localStorage.setItem('sw_history',JSON.stringify(h));renderSaved();}
function favs(){return JSON.parse(localStorage.getItem('sw_favs')||'[]');}
function toggleFav(zh){let f=favs();f=f.includes(zh)?f.filter(x=>x!==zh):[zh,...f];localStorage.setItem('sw_favs',JSON.stringify(f));renderDictionary();renderSaved();}
function renderDictionary(){
 const q=norm($('dictSearch').value),cat=$('category').value;
 const filtered=all.filter(x=>(!q||norm(x.zh).includes(q)||norm(frenchFor(x)).includes(q)||norm(x.variants.map(v=>v.reading||'').join(' ')).includes(q)||norm(x.variants.map(v=>v.latin||'').join(' ')).includes(q))&&(cat==='all'||x.category===cat));
 $('dictCount').textContent=`${filtered.length} / ${all.length}条`;
 $('dictResults').innerHTML=filtered.slice(0,250).map(x=>{const f=favs().includes(x.zh),vs=uniqueLocalVariants(x),fr=frenchFor(x);return `<div class="dictrow"><div class="dictmain"><div class="dictzh">${esc(x.zh)}</div><div class="dictrd">${esc(vs.map(v=>v.reading).filter(Boolean).join(' / '))}</div>${fr?`<div class="dictmeta">法语备用：${esc(fr)}</div><div class="dictmeta">法语近似读音：${esc(frenchReadingFor(fr,localFrenchPronOverride(x)))}</div>`:''}${vs.some(v=>v.latin)?`<div class="dictmeta">当地拼写：${esc(vs.map(v=>v.latin).filter(Boolean).join(' / '))}</div>`:''}<div class="dictmeta">${esc(x.category)} · ${vs.length}种当地记录 · ${esc(vs.map(v=>v.source).join('；'))}</div></div><button class="star ${f?'on':''}" data-fav="${esc(x.zh)}">${f?'★':'☆'}</button></div>`;}).join('')||'<div class="nores">没有找到匹配词条。</div>';
 $('dictResults').querySelectorAll('[data-fav]').forEach(b=>b.addEventListener('click',()=>toggleFav(b.dataset.fav)));
}
function renderSaved(){
 const f=favs();$('favCount').textContent=`${f.length}条`;
 $('favorites').innerHTML=f.map(zh=>{const x=map.get(norm(zh));return `<div class="dictrow"><div class="dictmain"><div class="dictzh">${esc(zh)}</div><div class="dictrd">${esc(x?uniqueLocalVariants(x).map(v=>v.reading).filter(Boolean).join(' / '):'')}</div></div><button class="plain mini" data-unfav="${esc(zh)}">取消</button></div>`;}).join('')||'<div class="nores">还没有收藏词条。在词库查询页面点 ☆ 即可收藏。</div>';
 $('favorites').querySelectorAll('[data-unfav]').forEach(b=>b.addEventListener('click',()=>toggleFav(b.dataset.unfav)));
 const h=JSON.parse(localStorage.getItem('sw_history')||'[]');$('history').innerHTML=h.map(phrase=>`<div class="dictrow"><div class="dictmain"><div class="dictzh">${esc(phrase)}</div></div><button class="soft mini" data-use="${esc(phrase)}">重新查询</button></div>`).join('')||'<div class="nores">还没有查询历史。</div>';
 $('history').querySelectorAll('[data-use]').forEach(b=>b.addEventListener('click',()=>{$('inputText').value=b.dataset.use;switchTab('translate');renderTranslation();window.scrollTo({top:0,behavior:'smooth'});}));
}
function renderCustomList(){
 $('customCount').textContent=`已添加 ${custom.length} 条`;
 $('customList').innerHTML=custom.slice().reverse().map(c=>`<div class="dictrow"><div class="dictmain"><div class="dictzh">${esc(c.zh)}</div><div class="dictrd">${esc(c.reading||'')}</div>${c.latin?`<div class="dictmeta">当地拼写：${esc(c.latin)}</div>`:''}${c.french?`<div class="dictmeta">法语备用：${esc(c.french)}</div><div class="dictmeta">法语近似读音：${esc(frenchReadingFor(c.french,c.frenchReadingZh))}</div>`:''}<div class="dictmeta">${esc(c.category||'其他')} · ${esc(c.source||'用户手动添加')}${c.note?' · '+esc(c.note):''}</div></div><div class="custom-actions"><button class="soft mini" data-edit-custom="${esc(c.id)}">编辑</button><button class="plain mini" data-delete-custom="${esc(c.id)}">删除</button></div></div>`).join('')||'<div class="nores">你还没有手动添加词条。上面的表格可以新增第一条。</div>';
 $('customList').querySelectorAll('[data-edit-custom]').forEach(b=>b.addEventListener('click',()=>editCustom(b.dataset.editCustom)));
 $('customList').querySelectorAll('[data-delete-custom]').forEach(b=>b.addEventListener('click',()=>{const id=b.dataset.deleteCustom,entry=custom.find(c=>c.id===id);if(!entry)return;if(!window.confirm(`确定删除“${entry.zh}”这条自定义词条吗？原始资料中的词条不会被删除。`))return;deleteCustomEntry(id);renderAll();setMessage('已删除这条自定义词条。','ok');}));
}
function formData(){return {zh:$('newZh').value,latin:$('newLatin').value,reading:$('newReading').value,french:$('newFrench').value,frenchReadingZh:$('newFrenchReadingZh').value,category:$('newCategory').value,source:$('newSource').value,note:$('newNote').value};}
let editingId=null;
function clearEntryForm(){editingId=null;$('entryForm').reset();$('newCategory').value='其他';$('newSource').value='用户手动添加';$('entrySubmit').textContent='保存新词条';$('cancelEdit').hidden=true;$('entryFormTitle').textContent='手动添加新词条';}
function editCustom(id){const c=custom.find(x=>x.id===id);if(!c)return;editingId=id;$('newZh').value=c.zh;$('newLatin').value=c.latin||'';$('newReading').value=c.reading||'';$('newFrench').value=c.french||'';$('newFrenchReadingZh').value=c.frenchReadingZh||'';$('newCategory').value=c.category||'其他';$('newSource').value=c.source||'用户手动添加';$('newNote').value=c.note||'';$('entrySubmit').textContent='保存修改';$('cancelEdit').hidden=false;$('entryFormTitle').textContent='编辑自定义词条';$('newZh').focus();window.scrollTo({top:0,behavior:'smooth'});}
function setMessage(s,type){$('maintenanceMessage').textContent=s;$('maintenanceMessage').className='form-message '+(type||'');}
function renderAll(){rebuild();renderDictionary();renderSaved();renderCustomList();}
function switchTab(tab){document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));document.querySelectorAll('.panel').forEach(p=>p.classList.toggle('active',p.id===tab));if(tab==='dictionary')renderDictionary();if(tab==='saved')renderSaved();if(tab==='maintenance')renderCustomList();}
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>switchTab(b.dataset.tab)));
$('translateBtn').addEventListener('click',renderTranslation);$('clearBtn').addEventListener('click',()=>{$('inputText').value='';renderTranslation();});$('saveHistoryBtn').addEventListener('click',()=>{const t=$('inputText').value.trim();if(t)saveRecent(t);});$('dictSearch').addEventListener('input',renderDictionary);$('category').addEventListener('change',renderDictionary);$('clearHistory').addEventListener('click',()=>{localStorage.removeItem('sw_history');renderSaved();});
async function copyText(text,buttonId,defaultLabel){try{await navigator.clipboard.writeText(text);$(buttonId).textContent='已复制';}catch(e){const ta=document.createElement('textarea');ta.value=text;document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();$(buttonId).textContent='已复制';}setTimeout(()=>{$(buttonId).textContent=defaultLabel;},1800);}
$('copyReading').addEventListener('click',()=>copyText($('resultReading').textContent,'copyReading','复制读音'));
$('copyFrench').addEventListener('click',()=>copyText($('resultFrench').textContent,'copyFrench','复制法语'));
$('copyFrenchReading').addEventListener('click',()=>copyText($('resultFrenchReading').textContent,'copyFrenchReading','复制法语谐音'));
$('entryForm').addEventListener('submit',e=>{e.preventDefault();const wasEditing=!!editingId,id=editingId,d=formData(),r=wasEditing?updateCustomEntry(id,d):addCustomEntry(d);if(!r.ok){setMessage(r.error,'err');return;}clearEntryForm();renderAll();setMessage(wasEditing?'已修改，短句匹配时立即生效。':'已添加新词条，短句匹配时立即生效。','ok');});
$('cancelEdit').addEventListener('click',()=>{clearEntryForm();setMessage('已取消编辑。','');});
$('exportCustom').addEventListener('click',()=>{$('backupText').value=exportCustom();$('backupText').focus();$('backupText').select();setMessage('备份内容已生成。请复制下面文本，保存到手机备忘录或电脑文件中。','ok');});
$('copyBackup').addEventListener('click',()=>{const t=$('backupText').value;if(!t){setMessage('请先点击“生成备份”。','err');return;}copyText(t,'copyBackup','复制备份文本').then(()=>setMessage('备份 JSON 已复制。请粘贴到备忘录保存。','ok'));});
$('importCustom').addEventListener('click',()=>{const t=$('restoreText').value.trim();if(!t){setMessage('请先粘贴备份 JSON。','err');return;}const r=importCustom(t);if(!r.ok){setMessage(r.error,'err');return;}renderAll();setMessage(`恢复完成：新增 ${r.added} 条，更新 ${r.updated} 条，跳过 ${r.skipped} 条。${r.legacy?'另有旧版仅英语备用条目 '+r.legacy+' 条未自动转换为法语，请手动补充法语。':''}`,'ok');});
const examples=['请稍等','请进','谢谢','请你明天早上到办公室集合','所有人员立即到门岗集合','请检查所有车辆','柴油','警卫','你在哪里？'];
$('samples').innerHTML=examples.map(x=>`<button class="sample" data-sample="${esc(x)}">${esc(x)}</button>`).join('');$('samples').querySelectorAll('[data-sample]').forEach(b=>b.addEventListener('click',()=>{$('inputText').value=b.dataset.sample;renderTranslation();}));
window.KolweziSwahili={get dictCount(){return all.length;},get customCount(){return custom.length;},get frenchFallbackCount(){return FRENCH_MAP.size;},translate:(text)=>tokenize(text),exact:(text)=>map.get(norm(text))||null,addCustom:addCustomEntry,updateCustom:updateCustomEntry,deleteCustom:deleteCustomEntry,exportCustom,importCustom,getCustom:()=>custom.map(x=>({...x})),french:(text)=>FRENCH_MAP.get(norm(text))||'',frenchReading:frenchReadingFor};
renderDictionary();renderSaved();renderCustomList();clearEntryForm();
if(location.hash==='#smoke'){
 $('inputText').value='请稍等，我去叫他';renderTranslation();const a=$('resultReading').textContent.includes('穷噶')||$('resultReading').textContent.includes('请稍等');
 $('inputText').value='请你明天早上到办公室集合';renderTranslation();const b=$('resultFrench').textContent.includes('rassembler')||$('resultFrench').textContent.includes('Veuillez');
 $('inputText').value='请出示身份证';renderTranslation();const c=$('resultFrenchReading').textContent.trim().length>0;
 document.body.insertAdjacentHTML('beforeend',`<div id="smokeResult" data-ok="${a&&b&&c}" style="position:fixed;bottom:4px;right:4px;background:#153f34;color:white;padding:6px 10px;border-radius:7px;font:12px monospace">SMOKE ${a&&b&&c?'PASS':'CHECK'} · 本地词条 ${all.length} · 法语 ${FRENCH_MAP.size}</div>`);
}
})();
