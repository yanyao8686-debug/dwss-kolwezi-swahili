/* DWSS dictionary bootstrap. Gzip keeps the initial offline cache small. */
(async function () {
  'use strict';
  const showError = (message) => {
    const box = document.createElement('div');
    box.style.cssText = 'margin:16px;padding:16px;border:1px solid #a33;border-radius:12px;background:#fff4f2;color:#7a2118;font:16px/1.6 system-ui,sans-serif';
    box.textContent = message;
    document.body.prepend(box);
  };
  try {
    if (typeof DecompressionStream !== 'function') {
      throw new Error('当前浏览器版本过旧，无法读取离线压缩词库。请更新 Chrome；iPhone 请使用 iOS 16.4 或更新版本的 Safari。');
    }
    const response = await fetch('./dictionary.js.gz');
    if (!response.ok) throw new Error('词库文件下载失败（HTTP ' + response.status + '）。请联网重新加载 DWSS。');
    const decompressed = response.body.pipeThrough(new DecompressionStream('gzip'));
    const source = await new Response(decompressed).text();
    const blobUrl = URL.createObjectURL(new Blob([source], {type:'text/javascript'}));
    await new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = blobUrl;
      script.onload = resolve;
      script.onerror = () => reject(new Error('词库加载失败，请重新打开软件。'));
      document.body.appendChild(script);
    });
    URL.revokeObjectURL(blobUrl);
    for (const src of ['./french-fallback.js', './app.js', './pwa.js']) {
      await new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = src;
        script.onload = resolve;
        script.onerror = () => reject(new Error('软件模块加载失败：' + src));
        document.body.appendChild(script);
      });
    }
  } catch (error) {
    console.error('[DWSS] bootstrap error', error);
    showError('DWSS 暂时无法启动：' + (error && error.message ? error.message : String(error)) + '。首次打开请联网后刷新；如果刚更新版本，请清除旧缓存后重新打开。');
  }
})();
