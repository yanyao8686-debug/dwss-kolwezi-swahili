# DWSS PWA 0.6.3 发布

本仓库通过 GitHub Actions 发布到 GitHub Pages。

1. 上传本次提供的 `DWSS_PWA_0.6.3_GitHubPages_发布包.zip` 到仓库根目录（ZIP 本身，不要解压或改名）。
2. Commit changes 后打开 Actions，等待 `Deploy DWSS PWA to GitHub Pages` 显示绿色勾号。
3. 安装地址：`https://yanyao8686-debug.github.io/dwss-kolwezi-swahili/`。

本版显示规则：加丹加斯瓦西里语中文谐音优先；精确词条缺失时先尝试已核对的近义当地词条；仍无合适词条才用法语补位，法语主体显示中文近似读音并标注“（法语）”。法语原文放在可展开的辅助区。近义替代会在逐段详情注明，不能保证完全同义，重要指令需当地人员核验。
