(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const state = $('pwaState');
  const message = $('pwaMessage');
  const networkBadge = $('networkBadge');
  const installButton = $('installAppBtn');
  const updateButton = $('checkUpdateBtn');
  let deferredInstallPrompt = null;
  let registration = null;
  let reloading = false;

  const isStandalone = () => window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  const setState = (text, kind, detail) => {
    state.textContent = text;
    state.className = 'chip ' + (kind || '');
    if (detail) message.textContent = detail;
  };
  const updateNetwork = () => {
    const online = navigator.onLine;
    networkBadge.textContent = online ? '● 网络已连接' : '● 当前离线';
    networkBadge.style.borderColor = online ? '#ffffff70' : '#ffdf9a';
    networkBadge.style.color = online ? '#e6fff3' : '#ffdf9a';
    if (!online && navigator.serviceWorker && navigator.serviceWorker.controller) {
      setState('离线运行中', 'pwa-state-ok', '当前没有网络连接。只要首次缓存已经完成，词库查询、短句匹配和个人词库维护仍可在本机使用。');
    }
  };

  window.addEventListener('online', updateNetwork);
  window.addEventListener('offline', updateNetwork);

  if (isStandalone()) {
    setState('已从桌面启动', 'pwa-state-ok', 'DWSS 已以独立窗口方式运行。第一次安装后请完成一次联网缓存，之后可离线使用。');
  } else {
    setState('浏览器打开', 'pwa-state-warn', '首次打开必须联网。请等待本页面、完整词库、DWSS 封面和图标缓存完成；确认离线资源已缓存后，再断网测试。');
  }

  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    deferredInstallPrompt = event;
    installButton.hidden = false;
    installButton.textContent = '安装到手机桌面';
  });

  installButton.addEventListener('click', async () => {
    if (!deferredInstallPrompt) return;
    deferredInstallPrompt.prompt();
    await deferredInstallPrompt.userChoice.catch(() => null);
    deferredInstallPrompt = null;
    installButton.hidden = true;
  });

  window.addEventListener('appinstalled', () => {
    installButton.hidden = true;
    setState('安装完成', 'pwa-state-ok', 'DWSS 已添加到手机桌面。请打开一次，确认词库已缓存；以后可断网使用。');
  });

  if (!window.isSecureContext && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') {
    setState('需要 HTTPS', 'pwa-state-bad', '浏览器只有在 HTTPS 安全网址（或本机 localhost）下才允许启用离线缓存和桌面安装。请勿使用普通 http:// 公网地址。');
  }

  if ('serviceWorker' in navigator && (window.isSecureContext || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    window.addEventListener('load', async () => {
      try {
        registration = await navigator.serviceWorker.register('./sw.js', { scope: './' });
        await navigator.serviceWorker.ready;
        if (navigator.storage && navigator.storage.persist) {
          navigator.storage.persist().then((granted) => {
            if (granted) console.info('[DWSS] 浏览器已授予持久化存储。');
          }).catch(() => {});
        }
        if (registration.waiting && navigator.serviceWorker.controller) showUpdateAvailable();
        registration.addEventListener('updatefound', () => {
          const worker = registration.installing;
          if (!worker) return;
          worker.addEventListener('statechange', () => {
            if (worker.state === 'installed' && navigator.serviceWorker.controller) showUpdateAvailable();
            else if (worker.state === 'activated') {
              setState('离线资源已缓存', 'pwa-state-ok', '核心程序、词库、封面和图标已由 Service Worker 缓存。现在可以断开网络测试。');
            }
          });
        });
        if (navigator.serviceWorker.controller) {
          setState('离线资源已缓存', 'pwa-state-ok', '核心程序、词库、封面和图标已缓存。现在可以断开网络测试。');
        } else {
          setState('正在启用离线缓存', 'pwa-state-warn', '核心文件正在缓存。首次缓存完成后，浏览器会接管离线访问；建议重新打开一次本软件再断网。');
        }
        updateNetwork();
      } catch (error) {
        console.error('[DWSS] Service Worker registration failed:', error);
        setState('离线缓存未完成', 'pwa-state-bad', '浏览器未能启用离线缓存。请确认使用 HTTPS，并重新加载页面；首次访问需要网络。');
      }
    });
  } else if ('serviceWorker' in navigator) {
    setState('等待安全网址', 'pwa-state-warn', '请通过 HTTPS 官方网址打开本软件，浏览器才能启用 PWA 安装和离线缓存。');
  } else {
    setState('浏览器不支持离线安装', 'pwa-state-bad', '当前浏览器不支持 Service Worker。建议使用较新版本的 Chrome 或 Safari。');
  }

  function showUpdateAvailable() {
    updateButton.textContent = '安装软件更新';
    updateButton.classList.add('primary');
    updateButton.classList.remove('soft');
    updateButton.dataset.updateReady = '1';
    setState('发现新版本', 'pwa-state-warn', '有新的 DWSS 软件版本已下载。点击“安装软件更新”后将刷新页面。更新不会主动删除本机自定义词库，但仍建议先备份。');
  }

  updateButton.addEventListener('click', async () => {
    if (updateButton.dataset.updateReady === '1' && registration && registration.waiting) {
      registration.waiting.postMessage({ type: 'DWSS_SKIP_WAITING' });
      return;
    }
    if (!registration) {
      setState('尚未连接更新服务', 'pwa-state-warn', '请先通过 HTTPS 打开并完成首次加载；离线状态下无法检查服务器是否有新版本。');
      return;
    }
    if (!navigator.onLine) {
      setState('当前离线', 'pwa-state-warn', '没有网络，无法检查服务器更新；已缓存的软件仍可继续使用。');
      return;
    }
    try {
      await registration.update();
      if (!registration.waiting && !registration.installing) setState('当前已是最新缓存版本', 'pwa-state-ok', '没有检测到新版本。软件仍可离线使用。');
    } catch (_) {
      setState('更新检查失败', 'pwa-state-warn', '网络连接或服务器暂时不可用；当前已缓存版本仍可使用。');
    }
  });

  navigator.serviceWorker?.addEventListener('controllerchange', () => {
    if (reloading) return;
    reloading = true;
    window.location.reload();
  });
  updateNetwork();
})();
