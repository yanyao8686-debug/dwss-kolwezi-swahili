(()=>{
'use strict';
const DB=Array.isArray(window.SW_DB)?window.SW_DB:[];
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const norm=s=>String(s||'').normalize('NFKC').replace(/[\s　]+/g,'').replace(/[，。！？；：、,.!?;:（）()“”"']/g,'').toLowerCase();
const CUSTOM_KEY='sw_custom_dictionary_v1';
const PRODUCT_META=Object.freeze({id:'com.dwss.kolwezi.swahili',name:'DWSS 科卢韦齐斯瓦西里语助手',owner:'DWSS / 陈谍',version:'0.5.1'});
const CATEGORIES=['安保与工作','矿山与设备','日常生活','时间与方位','人称与关系','医疗与健康','市场与饮食','其他'];
function categoryOf(zh){
 const s=zh;
 if(/警卫|警察|门岗|安保|保安|警告|保护|服从|罚款|签字|巡逻|检查|许可|请求|人员|身份证|护照|抓|偷|盗|不允许|不同意|同意|安全|纪律/.test(s))return '安保与工作';
 if(/矿|铜|钴|硫酸|厂房|发电机|发动机|挖掘机|吊车|柴油|汽油|机油|液压|电缆|电线|电机|水泥|混凝土|沙子|石子|搅拌机|设备|装车|工程|油桶|氧气|变压器|电焊|工具|库房|仓库|营地|办公室|主厂房/.test(s))return '矿山与设备';
 if(/昨天|今天|明天|后天|上午|中午|下午|晚上|早上|时间|分钟|小时|星期|前面|后面|左|右|上边|下边|这里|那里|现在/.test(s))return '时间与方位';
 if(/我|你|他|她|我们|你们|他们|先生|女士|男人|女人|小孩|老婆|丈夫|朋友|老人|刚果人|外国人/.test(s))return '人称与关系';
 if(/医院|医生|护士|药|疼|病|疟疾|肚子|头|眼|耳|嘴|手|脚|咳嗽|血/.test(s))return '医疗与健康';
 if(/买|卖|钱|市场|商店|公斤|蔬菜|西红柿|肉|米|饭|水|盐|油|糖|面粉|牛肉|羊肉|猪肉|鱼|喝|吃|饿/.test(s))return '市场与饮食';
 if(/你好|谢谢|请|再见|家|房子|门|窗|床|桌子|衣服|鞋|洗澡|睡觉|起床|厕所|走|过来|回来|去|来|说话|听|看|知道|明白|喜欢|帮助|累|休息/.test(s))return '日常生活';
 return '其他';
}
function loadCustom(){try{const x=JSON.parse(localStorage.getItem(CUSTOM_KEY)||'[]');return Array.isArray(x)?x.filter(v=>v&&typeof v.zh==='string'&&typeof v.reading==='string'):[]}catch(e){return [];}}
let custom=loadCustom();
let all=[],map=new Map(),keys=[];
function saveCustom(){localStorage.setItem(CUSTOM_KEY,JSON.stringify(custom));}
function rebuild(){
 const grouped=new Map();
 for(const item of DB){if(!item||!item.zh)continue;const k=norm(item.zh);if(!k)continue;
  if(!grouped.has(k))grouped.set(k,{zh:item.zh,variants:(item.variants||[]).map(v=>({...v})),category:categoryOf(item.zh),customIds:[]});
  else grouped.get(k).variants.push(...(item.variants||[]).map(v=>({...v})));
 }
 for(const c of custom){const k=norm(c.zh);if(!k)continue;
  if(!grouped.has(k))grouped.set(k,{zh:c.zh,variants:[],category:c.category||categoryOf(c.zh),customIds:[]});
  const item=grouped.get(k);item.category=c.category||item.category||categoryOf(c.zh);item.customIds.push(c.id);
  item.variants.push({reading:c.reading,latin:c.latin||'',source:c.source||'用户手动添加',kind:'用户补充',note:c.note||'',customId:c.id});
 }
 all=[...grouped.values()];map=new Map(all.map(x=>[norm(x.zh),x]));keys=[...all].sort((a,b)=>norm(b.zh).length-norm(a.zh).length);
}
rebuild();
function bestVariant(item){const vs=item.variants||[];return vs.find(v=>v.customId)||vs.find(v=>v.source&&v.source.includes('文件1'))||vs[0]||{reading:'',latin:'',source:'',kind:''};}
function uniqueReadings(item){const seen=new Set();return (item.variants||[]).filter(v=>{const k=norm(v.reading)+'|'+norm(v.latin||'');if(seen.has(k))return false;seen.add(k);return true;});}
function makeId(){return 'u_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,8);}
function validateEntry(data){
 const zh=String(data.zh||'').trim(),reading=String(data.reading||'').trim(),latin=String(data.latin||'').trim();
 if(!zh)return '请填写中文意思。';
 if(!reading)return '请填写中文谐音读法。';
 if(zh.length>100)return '中文词条建议不超过100个字。';
 if(reading.length>200)return '中文谐音建议不超过200个字。';
 if(latin.length>200)return '斯瓦西里语拼写建议不超过200个字符。';
 return {zh,reading,latin,category:CATEGORIES.includes(data.category)?data.category:categoryOf(zh),source:String(data.source||'用户手动添加').trim().slice(0,100),note:String(data.note||'').trim().slice(0,500)};
}
function addCustomEntry(data){const v=validateEntry(data);if(typeof v==='string')return {ok:false,error:v};
 const duplicate=custom.find(c=>norm(c.zh)===norm(v.zh)&&norm(c.reading)===norm(v.reading)&&norm(c.latin)===norm(v.latin));
 if(duplicate)return {ok:false,error:'这条自定义词条已经存在。你可以在下方列表中编辑它。'};
 custom.push({...v,id:makeId(),createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()});saveCustom();rebuild();return {ok:true};
}
function updateCustomEntry(id,data){const i=custom.findIndex(c=>c.id===id);if(i<0)return {ok:false,error:'没有找到要修改的自定义词条。'};const v=validateEntry(data);if(typeof v==='string')return {ok:false,error:v};
 const dup=custom.find((c,j)=>j!==i&&norm(c.zh)===norm(v.zh)&&norm(c.reading)===norm(v.reading)&&norm(c.latin)===norm(v.latin));if(dup)return {ok:false,error:'相同的自定义词条已存在。'};
 custom[i]={...custom[i],...v,updatedAt:new Date().toISOString()};saveCustom();rebuild();return {ok:true};
}
function deleteCustomEntry(id){const n=custom.length;custom=custom.filter(c=>c.id!==id);if(custom.length===n)return false;saveCustom();rebuild();return true;}
function exportCustom(){return JSON.stringify({app:PRODUCT_META.name,productId:PRODUCT_META.id,owner:PRODUCT_META.owner,appVersion:PRODUCT_META.version,formatVersion:1,exportedAt:new Date().toISOString(),entries:custom},null,2);}
function importCustom(raw){let data;try{data=typeof raw==='string'?JSON.parse(raw):raw;}catch(e){return {ok:false,error:'备份内容不是有效的 JSON。'};}
 const entries=Array.isArray(data)?data:data&&Array.isArray(data.entries)?data.entries:null;if(!entries)return {ok:false,error:'没有找到 entries 词条数组。'};
 let added=0,updated=0,skipped=0;
 for(const e of entries){const v=validateEntry(e||{});if(typeof v==='string'){skipped++;continue;}const id=String(e.id||'');const byId=id?custom.findIndex(c=>c.id===id):-1;const byValue=custom.findIndex(c=>norm(c.zh)===norm(v.zh)&&norm(c.reading)===norm(v.reading)&&norm(c.latin)===norm(v.latin));
  if(byId>=0){custom[byId]={...custom[byId],...v,updatedAt:new Date().toISOString()};updated++;}
  else if(byValue>=0){skipped++;}
  else {custom.push({...v,id:id||makeId(),createdAt:e.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString()});added++;}
 }
 saveCustom();rebuild();return {ok:true,added,updated,skipped};
}
function tokenize(raw){
 const input=String(raw||'');let i=0;const seg=[];let hit=0,unhit=0;
 while(i<input.length){
  const ch=input[i];
  if(/[\s，。！？；：、,.!?;:\-—（）()“”"“”]/.test(ch)){seg.push({type:'punct',text:ch});i++;continue;}
  let found=null,foundLen=0;
  for(const item of keys){const k=item.zh;if(!k||k.length<1)continue;const slice=input.slice(i,i+k.length);if(norm(slice)===norm(k)&&k.length>foundLen){found=item;foundLen=k.length;}}
  if(found){const v=bestVariant(found);seg.push({type:'match',zh:input.slice(i,i+foundLen),canonical:found.zh,reading:v.reading,latin:v.latin||'',source:v.source,item:found});hit+=foundLen;i+=foundLen;}
  else {let j=i+1;while(j<input.length&&!/[\s，。！？；：、,.!?;:\-—（）()“”"']/ .test(input[j])){let exists=false;for(const it of keys){if(it.zh.length>1&&norm(input.slice(j,j+it.zh.length))===norm(it.zh)){exists=true;break;}}if(exists)break;j++;}seg.push({type:'unknown',text:input.slice(i,j)});unhit+=(j-i);i=j;}
 }
 return {segments:seg,hit,unhit};
}
function renderTranslation(){
 const raw=$('inputText').value.trim();if(!raw){$('resultState').textContent='等待输入';$('resultOriginal').textContent='尚未输入';$('resultReading').textContent='翻译后显示';$('resultReading').classList.add('empty');$('resultLatin').textContent='自定义词条中填写了拉丁拼写时，这里显示相应内容。';$('segmentList').innerHTML='<div class="nores">输入中文后，显示哪些部分在词库中找到、哪些需要补充。</div>';return;}
 $('resultOriginal').textContent=raw;
 const exact=map.get(norm(raw));
 if(exact){
  const variants=uniqueReadings(exact);const reading=variants.map(v=>v.reading).filter(Boolean).join(' / ');const latins=variants.map(v=>v.latin).filter(Boolean);
  $('resultReading').textContent=reading||'没有可用中文谐音';$('resultReading').classList.toggle('empty',!reading);$('resultLatin').textContent=latins.length?latins.join(' / '):'原始资料未提供经核验的拉丁字母拼写；可在词库维护中手动补充。';
  $('resultState').textContent='找到原文短语/词条';$('coverageChip').textContent='词库覆盖：100%（命中整条）';$('matchedChip').textContent='匹配片段：1';
  $('segmentList').innerHTML=variants.map(v=>`<div class="seg"><div class="zh">${esc(exact.zh)}</div><div class="rd">${esc(v.reading||'未填中文谐音')}${v.latin?`<div class="src">斯瓦西里语拼写：${esc(v.latin)}</div>`:''}<div class="src">${esc(v.source||'')} · ${esc(v.kind||'')}${v.note?' · '+esc(v.note):''}</div></div></div>`).join('');saveRecent(raw);return;
 }
 const r=tokenize(raw);const reading=r.segments.map(s=>s.type==='match'?s.reading:(s.type==='punct'?s.text:`【未收录：${s.text}】`)).join(' ').replace(/\s+([，。！？；：、,.!?;:])/g,'$1').replace(/([（(])\s+/g,'$1');
 const latin=r.segments.map(s=>s.type==='match'?(s.latin||'【该词未填写拉丁拼写】'):(s.type==='punct'?s.text:`【未收录：${s.text}】`)).join(' ').replace(/\s+([，。！？；：、,.!?;:])/g,'$1');
 $('resultReading').textContent=reading||'未找到可拼配词条';$('resultReading').classList.toggle('empty',!reading);$('resultLatin').textContent=latin||'没有可显示的拼写';
 const total=r.hit+r.unhit;const pct=total?Math.round(100*r.hit/total):0;
 $('resultState').textContent=r.unhit?'部分词语未收录':'词库词语已匹配';$('coverageChip').textContent=`词库覆盖：${pct}%（按字符估算）`;$('matchedChip').textContent=`匹配片段：${r.segments.filter(s=>s.type==='match').length}`;
 $('segmentList').innerHTML=r.segments.map(s=>{if(s.type==='punct')return `<div class="small-muted">标点 ${esc(s.text)}</div>`;if(s.type==='match'){const alts=uniqueReadings(s.item).filter(v=>norm(v.reading)!==norm(s.reading));const altHtml=alts.length?`<div class="src">资料另有读法：${alts.map(v=>esc(v.reading)+'（'+esc(v.source)+'）').join('；')}。请核对当地说法。</div>`:'';return `<div class="seg"><div class="zh">${esc(s.zh)}</div><div class="rd">${esc(s.reading)}${s.latin?`<div class="src">斯瓦西里语拼写：${esc(s.latin)}</div>`:''}<div class="src">词条：${esc(s.canonical)} · ${esc(s.source)}</div>${altHtml}</div></div>`;}return `<div class="seg unknown"><div class="zh">${esc(s.text)}</div><div class="rd">未收录，暂不能可靠翻译<div class="src">建议在“词库维护”中补充该词/整句的当地表达</div></div></div>`;}).join('')||'<div class="nores">没有匹配结果</div>';
 saveRecent(raw);
}
function saveRecent(raw){let h=JSON.parse(localStorage.getItem('sw_history')||'[]');h=[raw,...h.filter(x=>x!==raw)].slice(0,30);localStorage.setItem('sw_history',JSON.stringify(h));renderSaved();}
function favs(){return JSON.parse(localStorage.getItem('sw_favs')||'[]')}
function toggleFav(zh){let f=favs();f=f.includes(zh)?f.filter(x=>x!==zh):[zh,...f];localStorage.setItem('sw_favs',JSON.stringify(f));renderDictionary();renderSaved();}
function renderDictionary(){
 const q=norm($('dictSearch').value);const cat=$('category').value;
 const filtered=all.filter(x=>(!q||norm(x.zh).includes(q)||x.variants.some(v=>norm(v.reading).includes(q)||norm(v.latin||'').includes(q)))&&(cat==='all'||x.category===cat));
 $('dictCount').textContent=`${filtered.length} / ${all.length}条`;
 $('dictResults').innerHTML=filtered.slice(0,250).map(x=>{const f=favs().includes(x.zh);const variants=uniqueReadings(x);return `<div class="dictrow"><div class="dictmain"><div class="dictzh">${esc(x.zh)}</div><div class="dictrd">${esc(variants.map(z=>z.reading).filter(Boolean).join(' / '))}</div>${variants.some(z=>z.latin)?`<div class="dictmeta">斯瓦西里语拼写：${esc(variants.map(z=>z.latin).filter(Boolean).join(' / '))}</div>`:''}<div class="dictmeta">${esc(x.category)} · ${variants.length}种记录 · ${esc(variants.map(z=>z.source).join('；'))}</div></div><button class="star ${f?'on':''}" data-fav="${esc(x.zh)}">${f?'★':'☆'}</button></div>`;}).join('')||'<div class="nores">没有找到匹配词条。</div>';
 $('dictResults').querySelectorAll('[data-fav]').forEach(b=>b.addEventListener('click',()=>toggleFav(b.dataset.fav)));
}
function renderSaved(){
 const f=favs();$('favCount').textContent=`${f.length}条`;
 $('favorites').innerHTML=f.map(zh=>{const x=map.get(norm(zh));return `<div class="dictrow"><div class="dictmain"><div class="dictzh">${esc(zh)}</div><div class="dictrd">${esc(x?uniqueReadings(x).map(v=>v.reading).filter(Boolean).join(' / '):'')}</div></div><button class="plain mini" data-unfav="${esc(zh)}">取消</button></div>`;}).join('')||'<div class="nores">还没有收藏词条。在词库查询页面点 ☆ 即可收藏。</div>';
 $('favorites').querySelectorAll('[data-unfav]').forEach(b=>b.addEventListener('click',()=>toggleFav(b.dataset.unfav)));
 const h=JSON.parse(localStorage.getItem('sw_history')||'[]');$('history').innerHTML=h.map(phrase=>`<div class="dictrow"><div class="dictmain"><div class="dictzh">${esc(phrase)}</div></div><button class="soft mini" data-use="${esc(phrase)}">重新查询</button></div>`).join('')||'<div class="nores">还没有查询历史。</div>';
 $('history').querySelectorAll('[data-use]').forEach(b=>b.addEventListener('click',()=>{$('inputText').value=b.dataset.use;switchTab('translate');renderTranslation();window.scrollTo({top:0,behavior:'smooth'});}));
}
function renderCustomList(){
 $('customCount').textContent=`已添加 ${custom.length} 条`;
 $('customList').innerHTML=custom.slice().reverse().map(c=>`<div class="dictrow"><div class="dictmain"><div class="dictzh">${esc(c.zh)}</div><div class="dictrd">${esc(c.reading)}</div>${c.latin?`<div class="dictmeta">当地拼写：${esc(c.latin)}</div>`:''}<div class="dictmeta">${esc(c.category||'其他')} · ${esc(c.source||'用户手动添加')}${c.note?' · '+esc(c.note):''}</div></div><div class="custom-actions"><button class="soft mini" data-edit-custom="${esc(c.id)}">编辑</button><button class="plain mini" data-delete-custom="${esc(c.id)}">删除</button></div></div>`).join('')||'<div class="nores">你还没有手动添加词条。上面的表格可以新增第一条。</div>';
 $('customList').querySelectorAll('[data-edit-custom]').forEach(b=>b.addEventListener('click',()=>editCustom(b.dataset.editCustom)));
 $('customList').querySelectorAll('[data-delete-custom]').forEach(b=>b.addEventListener('click',()=>{const id=b.dataset.deleteCustom;const entry=custom.find(c=>c.id===id);if(!entry)return;if(!window.confirm(`确定删除“${entry.zh}”这条自定义词条吗？原始资料中的词条不会被删除。`))return;deleteCustomEntry(id);renderAll();setMessage('已删除这条自定义词条。','ok');}));
}
function formData(){return {zh:$('newZh').value,latin:$('newLatin').value,reading:$('newReading').value,category:$('newCategory').value,source:$('newSource').value,note:$('newNote').value};}
let editingId=null;
function clearEntryForm(){editingId=null;$('entryForm').reset();$('newCategory').value='其他';$('newSource').value='用户手动添加';$('entrySubmit').textContent='保存新词条';$('cancelEdit').hidden=true;$('entryFormTitle').textContent='手动添加新词条';}
function editCustom(id){const c=custom.find(x=>x.id===id);if(!c)return;editingId=id;$('newZh').value=c.zh;$('newLatin').value=c.latin||'';$('newReading').value=c.reading;$('newCategory').value=c.category||'其他';$('newSource').value=c.source||'用户手动添加';$('newNote').value=c.note||'';$('entrySubmit').textContent='保存修改';$('cancelEdit').hidden=false;$('entryFormTitle').textContent='编辑自定义词条';$('newZh').focus();window.scrollTo({top:0,behavior:'smooth'});}
function setMessage(s,type){$('maintenanceMessage').textContent=s;$('maintenanceMessage').className='form-message '+(type||'');}
function renderAll(){rebuild();renderDictionary();renderSaved();renderCustomList();}
function switchTab(tab){document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));document.querySelectorAll('.panel').forEach(p=>p.classList.toggle('active',p.id===tab));if(tab==='dictionary')renderDictionary();if(tab==='saved')renderSaved();if(tab==='maintenance')renderCustomList();}
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>switchTab(b.dataset.tab)));
$('translateBtn').addEventListener('click',renderTranslation);$('clearBtn').addEventListener('click',()=>{$('inputText').value='';renderTranslation();});$('saveHistoryBtn').addEventListener('click',()=>{const t=$('inputText').value.trim();if(t)saveRecent(t);});$('dictSearch').addEventListener('input',renderDictionary);$('category').addEventListener('change',renderDictionary);$('clearHistory').addEventListener('click',()=>{localStorage.removeItem('sw_history');renderSaved();});
$('copyReading').addEventListener('click',async()=>{const t=$('resultReading').textContent;if(!t||t==='翻译后显示')return;try{await navigator.clipboard.writeText(t);$('copyReading').textContent='已复制';}catch(e){const ta=document.createElement('textarea');ta.value=t;document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();$('copyReading').textContent='已复制';}});
$('entryForm').addEventListener('submit',e=>{e.preventDefault();const wasEditing=!!editingId;const id=editingId;const d=formData();const r=wasEditing?updateCustomEntry(id,d):addCustomEntry(d);if(!r.ok){setMessage(r.error,'err');return;}clearEntryForm();renderAll();setMessage(wasEditing?'已修改，翻译和查询时立即生效。':'已添加新词条，翻译和查询时立即生效。','ok');});
$('cancelEdit').addEventListener('click',()=>{clearEntryForm();setMessage('已取消编辑。','');});
$('exportCustom').addEventListener('click',()=>{$('backupText').value=exportCustom();$('backupText').focus();$('backupText').select();setMessage('备份内容已生成。请复制下面文本，保存到手机备忘录或电脑文件中。','ok');});
$('copyBackup').addEventListener('click',async()=>{const t=$('backupText').value;if(!t){setMessage('请先点击“生成备份”。','err');return;}try{await navigator.clipboard.writeText(t);setMessage('备份 JSON 已复制。请粘贴到备忘录保存。','ok');}catch(e){$('backupText').focus();$('backupText').select();try{document.execCommand('copy');setMessage('已尝试复制备份文本。','ok');}catch(_){setMessage('请手动全选并复制文本。','err');}}});
$('importCustom').addEventListener('click',()=>{const t=$('restoreText').value.trim();if(!t){setMessage('请先粘贴备份 JSON。','err');return;}const r=importCustom(t);if(!r.ok){setMessage(r.error,'err');return;}renderAll();setMessage(`恢复完成：新增 ${r.added} 条，更新 ${r.updated} 条，跳过 ${r.skipped} 条。原始词库不会被覆盖。`,'ok');});
const examples=['请进','请稍等，我去叫他','你去哪里？','我不知道、我不懂','今天星期几呀？','把他叫过来','抓紧时间今天必须完成','警卫','柴油'];
$('samples').innerHTML=examples.map(x=>`<button class="sample" data-sample="${esc(x)}">${esc(x)}</button>`).join('');$('samples').querySelectorAll('[data-sample]').forEach(b=>b.addEventListener('click',()=>{$('inputText').value=b.dataset.sample;renderTranslation();}));
window.KolweziSwahili={get dictCount(){return all.length;},get customCount(){return custom.length;},translate:(text)=>tokenize(text),exact:(text)=>map.get(norm(text))||null,addCustom:addCustomEntry,updateCustom:updateCustomEntry,deleteCustom:deleteCustomEntry,exportCustom,importCustom,getCustom:()=>custom.map(x=>({...x}))};
renderDictionary();renderSaved();renderCustomList();clearEntryForm();
if(location.hash==='#smoke'){
 $('inputText').value='请稍等，我去叫他';renderTranslation();
 const ok=$('resultReading').textContent.includes('穷噶')&&$('segmentList').textContent.includes('穷噶');
 document.body.insertAdjacentHTML('beforeend',`<div id="smokeResult" data-ok="${ok}" style="position:fixed;bottom:4px;right:4px;background:#153f34;color:white;padding:6px 10px;border-radius:7px;font:12px monospace">SMOKE ${ok?'PASS':'CHECK'} · ${all.length} entries</div>`);
}
})();
