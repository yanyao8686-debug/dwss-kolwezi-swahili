#!/usr/bin/env python3
"""DWSS 0.9.111 visual-only refresh. Does not alter app functionality or cover artwork."""
from pathlib import Path
import hashlib, json, re, sys

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else "public")
VERSION = "0.9.111"
EXPECTED_COVER = "b6bce40baebb9b645e1d4ccac588e6c18291a0dca50fd8aa3aaca73fcb707a1a"
EXPECTED_APK = "9df93884f7eafe9e3cf8ba77d61c61e7a1b050360be691d1a39e6999e3fa37f5"

def file(name):
    p = ROOT / name
    if not p.is_file():
        raise SystemExit(f"Missing required release file: {name}")
    return p

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"{label}: expected exactly one match, found {count}")
    return text.replace(old, new, 1)

# Lock the supplied artwork and native Android package before touching web styles.
cover = file("cover.webp")
apk = file("DWSS-Android-Installer.apk")
if sha(cover) != EXPECTED_COVER:
    raise SystemExit("Top cover artwork hash differs from the approved 0.9.110 cover; aborting")
if sha(apk) != EXPECTED_APK:
    raise SystemExit("Android installer hash differs from the approved package; aborting")
cover_jpg = ROOT / "cover.jpg"
cover_jpg_hash = sha(cover_jpg) if cover_jpg.is_file() else None

html_path = file("index.html")
app_path = file("app.js")
sw_path = file("sw.js")
version_path = file("VERSION.txt")
manifest_path = file("manifest.webmanifest")
html = html_path.read_text(encoding="utf-8")
app = app_path.read_text(encoding="utf-8")
sw = sw_path.read_text(encoding="utf-8")
version_text = version_path.read_text(encoding="utf-8")
manifest = json.loads(manifest_path.read_text(encoding="utf-8"))

cover_markup_match = re.search(r'<section class="cover-frame".*?</section>', html, re.S)
if not cover_markup_match:
    raise SystemExit("Cannot identify the original top-cover markup; aborting")
cover_markup_before = cover_markup_match.group(0)

CSS = r'''
<style id="dwss-professional-visual-0111">
/* DWSS Professional 1.0 — visual layer only. Brand cover markup/artwork/styles are intentionally untouched. */
:root{
  --bg:#F1F4F8;
  --paper:#FFFFFF;
  --ink:#26364A;
  --muted:#718096;
  --line:#E2E7EF;
  --green:#123657;
  --green2:#EEF3F8;
  --orange:#D94C25;
  --orangebg:#FFF8EA;
  --red:#B94A34;
  --shadow:0 8px 24px rgba(18,54,87,.055);
  color-scheme:light;
}
body{
  background:linear-gradient(180deg,#EEF2F7 0%,#F4F6F9 360px,#F4F6F9 100%)!important;
  color:#26364A!important;
  font-family:"Noto Sans SC","PingFang SC","Microsoft YaHei",system-ui,-apple-system,"Segoe UI",sans-serif!important;
  font-size:15px;
  line-height:1.6;
}
/* Keep the top cover image, artwork overlay, dimensions and positioning untouched. */
.app{color:#26364A}
.ownership-banner .ownership-stamp{
  border-color:#E2E7EF!important;
  background:rgba(255,255,255,.92)!important;
  color:#68788C!important;
  border-radius:999px!important;
  font-size:10px!important;
  box-shadow:0 2px 8px rgba(18,54,87,.035);
}
.status-strip{
  background:#FFFFFF!important;
  border:1px solid #E2E7EF!important;
  border-radius:16px!important;
  box-shadow:0 4px 14px rgba(18,54,87,.035)!important;
  padding:8px 11px!important;
  margin-top:7px!important;
  margin-bottom:11px!important;
}
.status-strip .offline{
  background:#EFF7F2!important;
  border-color:#D6E7DC!important;
  color:#236248!important;
  font-size:12px!important;
}
.status-strip #pwaState{
  border:1px solid #E5E9EF!important;
  border-radius:999px!important;
  background:#EEF3F8!important;
  color:#40566F!important;
  font-size:12px!important;
  font-weight:650!important;
}
.status-strip #pwaState.pwa-state-ok{background:#EFF7F2!important;border-color:#D6E7DC!important;color:#236248!important}
.status-strip #pwaState.pwa-state-warn{background:#FFF7E8!important;border-color:#EAD9B4!important;color:#765A25!important}
.status-strip #pwaState.pwa-state-bad{background:#FFF1EE!important;border-color:#EFD5CF!important;color:#9D4436!important}
nav.tabs{
  background:rgba(255,255,255,.94)!important;
  border:1px solid #E2E7EF!important;
  border-radius:18px!important;
  box-shadow:0 5px 16px rgba(18,54,87,.045)!important;
  padding:8px!important;
  gap:8px!important;
}
nav.tabs .tab,
nav.tabs .nav-clear-slot,
nav.tabs .nav-clear-action{
  min-height:48px!important;
  border:1px solid #E1E7EF!important;
  border-radius:13px!important;
  background:#F3F6FA!important;
  color:#42566E!important;
  box-shadow:none!important;
  text-shadow:none!important;
  font-size:14px!important;
  font-weight:650!important;
  letter-spacing:0!important;
}
nav.tabs .tab.active{
  border-color:#123657!important;
  background:#123657!important;
  color:#FFFFFF!important;
  box-shadow:0 4px 11px rgba(18,54,87,.16)!important;
}
nav.tabs .nav-clear-slot:disabled{opacity:1!important;color:#52657B!important;cursor:default!important}
.card{
  border:1px solid #E2E7EF!important;
  border-radius:18px!important;
  background:#FFFFFF!important;
  box-shadow:0 6px 20px rgba(18,54,87,.045)!important;
  margin-bottom:14px;
}
.card h2{color:#263E58;font-size:18px;font-weight:700;letter-spacing:0!important;line-height:1.35}
.translation-workspace#translationWorkspace{
  border:1px solid #E1E7EF!important;
  border-radius:20px!important;
  background:#FFFFFF!important;
  box-shadow:0 7px 22px rgba(18,54,87,.05)!important;
}
.translation-input-section{padding:14px 16px 9px!important}
.translation-output-section{padding:9px 16px 17px!important;background:#FFFFFF!important}
.workspace-divider{background:#E8ECF1!important;margin:1px 14px!important}
.translation-input-section>h2,
#resultCard .sectionTitle h2{
  color:#D94C25!important;
  font-size:clamp(16px,4vw,18px)!important;
  font-weight:700!important;
  line-height:1.35!important;
  letter-spacing:0!important;
  text-decoration-color:#D94C25!important;
  text-decoration-thickness:1.5px!important;
  text-underline-offset:4px!important;
}
#resultCard .sectionTitle{gap:8px!important;margin-bottom:7px!important}
#resultCard .sectionTitle h2{flex:0 1 auto!important;min-width:0!important}
#resultCard .sectionTitle .chip{flex:0 0 auto!important}
#inputText{
  min-height:112px!important;
  padding:13px 14px!important;
  border:1px solid #E5D4AA!important;
  border-radius:16px!important;
  background:#FFF8EA!important;
  color:#26364A!important;
  font-size:23px!important;
  font-weight:500!important;
  line-height:1.55!important;
  box-shadow:inset 0 1px 2px rgba(70,54,25,.035)!important;
}
#inputText::placeholder{color:#9A8968!important;opacity:.85!important;font-size:15px!important}
#inputText:focus{
  border-color:#C9A75E!important;
  background:#FFFBF3!important;
  box-shadow:0 0 0 3px rgba(214,182,108,.19)!important;
}
#resultCard #resultReading{
  min-height:112px!important;
  padding:13px 14px!important;
  border:1px solid #E4D1A5!important;
  border-radius:16px!important;
  background:#FFF0D2!important;
  color:#183B60!important;
  font-family:"Noto Sans SC","PingFang SC","Microsoft YaHei",system-ui,sans-serif!important;
  font-size:clamp(24px,4.8vw,28px)!important;
  font-weight:650!important;
  line-height:1.55!important;
  letter-spacing:0!important;
  box-shadow:inset 0 1px 2px rgba(86,62,21,.035)!important;
}
#resultCard #resultReading.empty{font-size:16px!important;font-weight:450!important;color:#9B8B70!important}
#resultCard #resultReading::placeholder{color:#9B8B70!important;opacity:.88!important;font-size:15px!important}
#resultCard #resultReading:focus{
  border-color:#C9A75E!important;
  background:#FFF5E3!important;
  outline:none!important;
  box-shadow:0 0 0 3px rgba(214,182,108,.2)!important;
}
.resultlabel{color:#718096!important;font-size:12px!important;line-height:1.5!important}
#resultCard .dwss-secondary-title{color:#D94C25!important}
#resultCard .dwss-secondary-details .seg{border-bottom-color:#E7EBF0!important}
#resultCard .dwss-secondary-details .seg .zh{color:#30465D!important;font-size:13px!important;font-weight:650!important}
#resultCard .dwss-secondary-details .seg .rd{color:#42566E!important;font-size:13px!important}
#resultCard .dwss-secondary-details .seg.unknown{background:#FFF5F1!important;border-bottom-color:#F0DDD6!important}
.translation-correction-panel{
  margin:10px 0 7px!important;
  padding:10px 11px!important;
  border:1px solid #E9DFC8!important;
  border-radius:14px!important;
  background:#FFFCF6!important;
}
.translation-correction-hint,.translation-correction-panel .translation-correction-hint{
  color:#748196!important;
  font-size:12px!important;
  line-height:1.6!important;
}
.translation-correction-status{font-size:12px!important;line-height:1.55!important}
.translation-pronunciation-candidates{border-top:1px solid #E8E1D3!important;padding-top:9px!important;margin-top:9px!important}
.translation-pronunciation-candidates-title{color:#6A5630!important;font-size:13px!important;font-weight:700!important;margin-bottom:5px!important}
.translation-pronunciation-candidate{
  border:1px solid #E7E3D8!important;
  border-radius:11px!important;
  background:#FFFFFF!important;
  padding:7px 9px!important;
  box-shadow:0 2px 6px rgba(31,51,75,.025)!important;
}
.translation-pronunciation-candidate-reading{color:#263E58!important;font-size:15px!important;font-weight:650!important}
.translation-pronunciation-candidate-meta{color:#8190A2!important;font-size:11px!important}
.translation-pronunciation-choice{
  border:1px solid #E1E7EF!important;
  border-radius:9px!important;
  background:#F3F6FA!important;
  color:#3D536C!important;
  font-size:12px!important;
}
.translation-pronunciation-choice.selected{
  border-color:#D6B66C!important;
  background:#FFF3D8!important;
  color:#76551E!important;
}
.translation-pronunciation-pin{
  min-height:34px!important;
  padding:6px 10px!important;
  border:1px solid #D6B66C!important;
  border-radius:10px!important;
  background:#FFF3D8!important;
  color:#76551E!important;
  font-size:11px!important;
  font-weight:750!important;
}
button,
input,textarea,select{font-family:inherit}
button{border-radius:12px!important;font-weight:650!important;transition:background-color .16s ease,border-color .16s ease,box-shadow .16s ease,transform .16s ease}
button.primary,
#submitTranslationCorrection,
#entrySubmit,
#savePublicPronunciation,
#saveSharedVariantEdit{
  border:1px solid #174B7A!important;
  border-radius:13px!important;
  background:#174B7A!important;
  color:#FFFFFF!important;
  box-shadow:0 4px 11px rgba(23,75,122,.15)!important;
  text-shadow:none!important;
}
button.soft,
button.plain,
nav.tabs .nav-clear-slot,
nav.tabs .nav-clear-action{
  border:1px solid #DEE5ED!important;
  border-radius:12px!important;
  background:#F1F4F8!important;
  color:#42566E!important;
  box-shadow:none!important;
  text-shadow:none!important;
}
button.soft:hover,button.plain:hover{background:#EAF0F6!important;border-color:#CED8E4!important}
button.primary:hover,#submitTranslationCorrection:hover,#entrySubmit:hover{background:#123F68!important}
button:disabled{opacity:.55!important}
button:focus-visible,a:focus-visible,input:focus-visible,textarea:focus-visible,select:focus-visible{
  outline:3px solid rgba(36,91,139,.24)!important;
  outline-offset:2px!important;
}
.actions{gap:9px!important;margin-top:11px!important}
.actions button{min-height:44px!important;padding:10px 15px!important;font-size:15px!important}
button.mini,.mini{min-height:36px!important;padding:7px 10px!important;font-size:12px!important}
#copyReading{min-height:34px!important}
.chip,.pill{
  border:1px solid #E4E9F0!important;
  background:#F2F5F8!important;
  color:#5A6C82!important;
  border-radius:999px!important;
  font-size:11px!important;
}
.pill.sel{background:#E7EEF6!important;color:#24496B!important;border-color:#D5E0EB!important}
.hint,.small-muted{color:#718096!important;font-size:13px!important;line-height:1.65!important}
.search{
  min-height:46px!important;
  border:1px solid #E1D9C8!important;
  border-radius:13px!important;
  background:#FFFCF6!important;
  color:#26364A!important;
  font-size:16px!important;
  padding:11px 13px!important;
}
.search:focus{border-color:#C9A75E!important;box-shadow:0 0 0 3px rgba(214,182,108,.16)!important}
input:not([type="checkbox"]):not([type="radio"]):not([type="range"]):not([type="button"]):not([type="submit"]):not([type="reset"]),
.field textarea,.field select,.toolbar select{
  border-color:#E1D9C8!important;
  border-radius:11px!important;
  background:#FFFCF6!important;
  color:#26364A!important;
  font-size:16px!important;
}
input::placeholder,textarea::placeholder{color:#9A8968!important;opacity:.85}
.field{gap:7px!important}
.field label{color:#42566E!important;font-size:13px!important;font-weight:650!important}
.field input,.field select,.field textarea{min-height:46px!important;padding:11px 12px!important}
.field textarea{min-height:84px!important}
.dictrow{border-bottom-color:#E8ECF1!important;padding:13px 2px!important}
.dictzh{color:#263E58!important;font-size:16px!important}
.dictrd{color:#24577F!important;font-size:16px!important;font-weight:600!important}
.dictmeta{color:#8190A2!important;font-size:11px!important}
.star{background:#F2F5F8!important;color:#52677F!important;border:1px solid #E1E7EF!important;border-radius:10px!important}
.star.on{background:#FFF3D8!important;color:#76551E!important;border-color:#D6B66C!important}
.seg{border-color:#E3E8EF!important;border-radius:12px!important;background:#FFFFFF!important;padding:10px 11px!important}
.seg .zh{color:#263E58!important}
.seg .rd{color:#405A73!important;font-size:15px!important}
.segmentlist{gap:7px!important;margin-top:11px!important}
.unknown{background:#FFF5F1!important;border-color:#EED9D2!important}
.public-pronunciation-card{border-color:#E2E7EF!important;border-radius:14px!important;background:#F8FAFC!important;padding:13px!important}
.public-pronunciation-heading{color:#2E4660!important;font-size:14px!important}
.public-pronunciation-note{color:#748196!important;font-size:12px!important;line-height:1.6!important}
.public-pronunciation-row{border-top-color:#E7EBF0!important}
.public-pronunciation-zh{color:#2B4058!important;font-size:13px!important}
.public-pronunciation-reading{color:#24577F!important;font-size:14px!important}
.pronunciation-editor-dialog,.dwss-variant-dialog,.dwss-history-dialog{
  border:1px solid #E1E7EF!important;
  border-radius:18px!important;
  background:#FFFFFF!important;
  color:#26364A!important;
  box-shadow:0 18px 48px rgba(18,54,87,.18)!important;
}
.pronunciation-editor-dialog h2,.dwss-variant-dialog h2,.dwss-history-dialog h2{color:#263E58!important;font-size:18px!important}
.pronunciation-editor-word{background:#FFF8EA!important;color:#263E58!important;border-radius:11px!important}
#pronunciationEditorValue,.dwss-variant-dialog textarea{background:#FFF8EA!important;border:1px solid #E5D4AA!important;border-radius:12px!important;color:#26364A!important;font-size:17px!important}
.pronunciation-lookup-instruction{
  border:1px solid #E7DFC9!important;
  border-radius:14px!important;
  background:#FFF8EA!important;
  color:#68788C!important;
  font-size:14px!important;
  line-height:1.7!important;
  padding:12px 13px!important;
}
.recommendation-box,.recommendation-item{
  border-color:#E3E8EF!important;
  border-radius:13px!important;
  background:#FFFFFF!important;
}
.recommendation-title{color:#344D68!important;font-size:13px!important}
.recommendation-main>b{color:#263E58!important}
.recommendation-main>span{color:#405A73!important}
.maintenance-note,.form-message{
  border:1px solid #E7DFC9!important;
  border-radius:12px!important;
  background:#FFF8EA!important;
  color:#725D34!important;
  font-size:13px!important;
  line-height:1.65!important;
}
.form-message.ok{background:#EFF7F2!important;border-color:#D6E7DC!important;color:#236248!important}
.form-message.err{background:#FFF1EE!important;border-color:#EFD5CF!important;color:#9D4436!important}
#dwss-apk-download{
  border:1px solid #E2E7EF!important;
  border-radius:18px!important;
  background:#FFFFFF!important;
  box-shadow:0 6px 18px rgba(18,54,87,.05)!important;
}
#dwss-apk-download .apk-title{color:#263E58!important;font-size:13px!important}
#dwss-apk-download .apk-meta,#dwss-apk-download .apk-note{color:#8190A2!important;font-size:10px!important}
#dwss-apk-download .apk-download-btn{
  border:1px solid #174B7A!important;
  border-radius:12px!important;
  background:#174B7A!important;
  color:#FFFFFF!important;
  box-shadow:0 4px 11px rgba(23,75,122,.13)!important;
  font-size:13px!important;
}
#dwss-announcement-dialog{background:#FFF8EA!important;border-color:#E5D4AA!important;color:#26364A!important}
#dwss-announcement-head,#dwss-announcement-body,#dwss-announcement-actions{background:#FFF8EA!important;border-color:#E9DFC8!important}
#dwss-announcement-head h2,#dwss-announcement-body h3{color:#263E58!important}
#dwss-announcement-head p,#dwss-announcement-body{color:#566A81!important}
#dwss-announcement-platform{background:#EEF3F8!important;color:#40566F!important}
#dwss-announcement-close{background:#174B7A!important;color:#FFFFFF!important;border-radius:12px!important}
.pwa-toast{border:1px solid #E5D4AA!important;border-radius:14px!important;background:#FFF8EA!important;color:#5D4A25!important;box-shadow:0 10px 28px rgba(18,54,87,.14)!important}
.footer{color:#8995A5!important;font-size:11px!important}
@media(max-width:520px){
  .translation-input-section{padding:12px 13px 8px!important}
  .translation-output-section{padding:8px 13px 15px!important}
  #inputText{min-height:106px!important;font-size:22px!important}
  #resultCard #resultReading{min-height:108px!important;font-size:24px!important}
  nav.tabs{gap:6px!important;padding:7px!important}
  nav.tabs .tab,nav.tabs .nav-clear-slot,nav.tabs .nav-clear-action{min-height:48px!important;font-size:13px!important;padding:7px 2px!important}
  .actions button{min-height:43px!important}
  .translation-pronunciation-candidate{padding:7px 8px!important}
}
@media(min-width:760px){
  .card{padding:18px}
  #translationWorkspace.card{padding:0!important}
}
@media(prefers-reduced-motion:reduce){button{transition:none!important}}
</style>
'''
if 'id="dwss-professional-visual-0111"' in html:
    raise SystemExit("Professional visual layer already exists; refusing duplicate insertion")
html = replace_once(html, "</head>", CSS + "\n</head>", "insert professional visual layer")
html = replace_once(html, 'content="0.9.110"><!-- DWSS_AUTO_UPDATE_0_9_110 -->',
                    'content="0.9.111"><!-- DWSS_AUTO_UPDATE_0_9_111 -->', "HTML release marker")
html = html.replace("dwss-release=0.9.110", "dwss-release=0.9.111")
if html.count("dwss-release=0.9.111") != 3:
    raise SystemExit("Expected exactly three bootstrap cache-bust URLs after release bump")
html = replace_once(html, '<span id="apkWebVersion">0.9.105</span>',
                    '<span id="apkWebVersion">0.9.111</span>', "APK web version label")
html = replace_once(html, '<meta name="theme-color" content="#071b49">',
                    '<meta name="theme-color" content="#123657">', "browser theme color")
if re.search(r'\.cover-frame|\.cover-image|\.owner-signature|\.owner-cover-author', CSS):
    raise SystemExit("Visual override must never style top cover artwork or its overlay")
cover_markup_after = re.search(r'<section class="cover-frame".*?</section>', html, re.S)
if not cover_markup_after or cover_markup_after.group(0) != cover_markup_before:
    raise SystemExit("Top cover markup was changed; aborting")
html_path.write_text(html, encoding="utf-8")

# Only update app metadata version; the application logic remains byte-for-byte text-identical otherwise.
app = replace_once(app, "version:'0.9.110'", "version:'0.9.111'", "application metadata version")
app_path.write_text(app, encoding="utf-8")

sw = replace_once(sw, "const APP_VERSION = '0.9.110';",
                  "const APP_VERSION = '0.9.111';", "Service Worker cache version")
sw_path.write_text(sw, encoding="utf-8")

manifest["background_color"] = "#F1F4F8"
manifest["theme_color"] = "#123657"
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

version_text = replace_once(version_text, "Version: 0.9.110", "Version: 0.9.111", "VERSION.txt")
version_text = replace_once(version_text, "Release date: 2026-10-31", "Release date: 2026-10-31", "release date")
version_text += (
    "\n0.9.111: DWSS Professional 1.0 visual refresh — deep navy, champagne gold, warm ivory and light amber surfaces; "
    "soft-gray page background; consistent single-line borders, moderate rounded corners, readable typography, "
    "accessible button sizing and balanced mobile spacing across translation, pronunciation, dictionary, history, "
    "word entry, dialogs and Android download UI. Top cover artwork/markup and native Android APK remain unchanged.\n"
)
version_path.write_text(version_text, encoding="utf-8")

# Immutable asset checks after the patch.
if sha(cover) != EXPECTED_COVER or sha(apk) != EXPECTED_APK:
    raise SystemExit("Top cover or Android APK changed unexpectedly")
if cover_jpg_hash is not None and sha(cover_jpg) != cover_jpg_hash:
    raise SystemExit("Alternate cover image was changed unexpectedly")
print("PASS DWSS 0.9.111: visual-only design layer added; cover artwork/markup and APK unchanged.")
